@echo off
title ElectriApp - SIGES-ELEC
cd /d "%~dp0"

set "APP_URL=file:///%~dp0index.html"
set "APP_URL=%APP_URL:\=/%"

:: Si existe Node.js, node_modules y .env, levantar backend MySQL automaticamente
where node >nul 2>nul
if %errorlevel%==0 (
    if exist "node_modules" (
        if exist ".env" (
            echo [ElectriApp] Iniciando servidor MySQL + API en http://localhost:3000 ...
            start "ElectriApp-API" /min cmd /c "node src\server.js"
            timeout /t 2 /nobreak >nul
            set "APP_URL=http://localhost:3000"
        )
    )
)

:: Abrir en modo ventana de aplicacion de escritorio (sin barra de navegador)
if exist "%ProgramFiles%\Google\Chrome\Application\chrome.exe" (
    start "" "%ProgramFiles%\Google\Chrome\Application\chrome.exe" --app="%APP_URL%"
    exit /b 0
)
if exist "%ProgramFiles(x86)%\Google\Chrome\Application\chrome.exe" (
    start "" "%ProgramFiles(x86)%\Google\Chrome\Application\chrome.exe" --app="%APP_URL%"
    exit /b 0
)
if exist "%ProgramFiles(x86)%\Microsoft\Edge\Application\msedge.exe" (
    start "" "%ProgramFiles(x86)%\Microsoft\Edge\Application\msedge.exe" --app="%APP_URL%"
    exit /b 0
)
if exist "%ProgramFiles%\Microsoft\Edge\Application\msedge.exe" (
    start "" "%ProgramFiles%\Microsoft\Edge\Application\msedge.exe" --app="%APP_URL%"
    exit /b 0
)

:: Fallback al navegador predeterminado
start "" "%APP_URL%"
exit /b 0
