const path = require("path");
const express = require("express");
const helmet = require("helmet");
const cors = require("cors");
require("dotenv").config();

const { checkConnection } = require("./config/db");
const { apiLimiter, sanitizeBody } = require("./middleware/security");
const authRoutes = require("./routes/auth.routes");
const trabajosRoutes = require("./routes/trabajos.routes");
const adminRoutes = require("./routes/admin.routes");

const app = express();
const PORT = Number(process.env.PORT) || 3000;
const rootDir = path.join(__dirname, "..");

// Seguridad HTTP
app.use(
    helmet({
        contentSecurityPolicy: false
    })
);
app.use(cors());
app.use(express.json({ limit: "1mb" }));
app.use(sanitizeBody);
app.use("/api", apiLimiter);

// Healthcheck
app.get("/api/health", async (_req, res) => {
    try {
        await checkConnection();
        res.json({ status: "ok", mode: "MYSQL_API", database: process.env.DB_NAME || "AviGoZa_elec_db" });
    } catch (err) {
        res.status(503).json({ status: "degraded", error: "Sin conexión a MySQL: " + err.message });
    }
});

// Rutas API
app.use("/api/auth", authRoutes);
app.use("/api/trabajos", trabajosRoutes);
app.use("/api/admin", adminRoutes);

// Servir íconos PWA
app.use("/icons", express.static(path.join(rootDir, "icons")));

// Servir ÚNICAMENTE los archivos públicos del frontend y PWA en la raíz
// (bloquea el acceso web a .env, src/, bdd.sql o package.json)
const PUBLIC_FILES = new Set([
    "/index.html",
    "/style.css",
    "/script.js",
    "/manifest.json",
    "/sw.js"
]);

app.get(["/", "/index.html", "/style.css", "/script.js", "/manifest.json", "/sw.js"], (req, res) => {
    const file = req.path === "/" ? "index.html" : req.path.slice(1);
    if (!PUBLIC_FILES.has("/" + file)) {
        return res.status(404).end();
    }
    res.sendFile(path.join(rootDir, file));
});

app.use((_req, res) => {
    res.status(404).json({ error: "Recurso no encontrado." });
});

app.listen(PORT, () => {
    console.log(`⚡ ElectriApp / SIGES-ELEC corriendo en http://localhost:${PORT}`);
});
