# ⚡ ElectriApp · SIGES-ELEC (Instalable en PC y Celular)

Sistema de gestión de servicios técnicos y multioficio con **protocolo de seguridad obligatorio**, **panel Super Admin**, **exportación real a PDF**, **base de datos SQL (MySQL)** y soporte **PWA instalable (Android / iOS / PC)**.

---

## 💻 1. Usar ya mismo con Acceso Directo en tu PC (Windows)

1. Descomprimí toda la carpeta en una ubicación fija (ej. `C:\ElectriApp`).
2. Hacé doble clic en **`Crear-Acceso-Directo-PC.bat`**.
3. Te creará el ícono **⚡ ElectriApp SIGES** en tu Escritorio.
4. Al abrirlo con doble clic, se ejecuta como **aplicación de escritorio independiente** (sin barra del navegador):
   - Si todavía no configuraste MySQL, arranca al instante en **Modo Demo Local** (`localStorage`).
   - Si ya configuraste MySQL + `.env` + `npm install`, levanta automáticamente el servidor Node.js y se conecta a `AviGoZa_elec_db`.

---

## 📱 2. Instalar en Celular (Android / iOS) sin Compilar Nada

1. Subí estos archivos a tu repositorio `https://github.com/unavidagenial/electriapp` (rama `main`).
2. En GitHub entrá a **Settings → Pages → Branch: `main` (`/ (root)`) → Save**.
3. En 1 minuto vas a tener tu enlace HTTPS activo:
   `https://unavidagenial.github.io/electriapp/`
4. Abrí ese enlace desde Chrome (Android) o Safari (iPhone):
   - En **Android**: tocá el botón **📲 Instalar App** en el encabezado (o menú `⋮` → *Instalar aplicación*). Queda en tu pantalla de inicio con ícono propio y **funciona incluso sin internet**.
   - En **iPhone**: tocá **Compartir → Agregar a pantalla de inicio**.

### ¿Necesitás un archivo `.apk` instalable para compartir por WhatsApp?
Con la URL de GitHub Pages activa (`https://unavidagenial.github.io/electriapp/`), entrá a **https://www.pwabuilder.com**, pegá tu URL, hacé clic en **Package for Stores → Android → Generate Package** y descargás el **`.apk` firmado** en menos de 1 minuto.

---

## 🗄️ 3. Activar Conexión Real a MySQL (Opcional en PC/Servidor)

1. Ejecutá `bdd.sql` en MySQL Workbench para crear `AviGoZa_elec_db`.
2. Copiá `.env.example` a `.env` y completá tu usuario/clave de MySQL.
3. En la terminal dentro de la carpeta del proyecto:
   ```bash
   npm install
   npm run seed:admin
   npm start
   ```
4. Verificación automática de seguridad antes de subir cambios:
   ```bash
   npm run security:check
   ```

## 🔐 Acceso Super Admin Inicial
- **Email:** `admin@electriapp.com`
- **Contraseña:** `Admin#2026`
