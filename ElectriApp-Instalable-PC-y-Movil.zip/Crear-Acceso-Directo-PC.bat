@echo off
title Instalador de Acceso Directo - ElectriApp SIGES
cd /d "%~dp0"

echo ========================================================
echo   Creando acceso directo de ElectriApp en el Escritorio
echo ========================================================
echo.

powershell -NoProfile -ExecutionPolicy Bypass -Command ^
  "$WshShell = New-Object -ComObject WScript.Shell; " ^
  "$Desktop = [Environment]::GetFolderPath('Desktop'); " ^
  "$Shortcut = $WshShell.CreateShortcut((Join-Path $Desktop 'ElectriApp SIGES.lnk')); " ^
  "$Shortcut.TargetPath = (Join-Path '%~dp0' 'Iniciar-ElectriApp.bat'); " ^
  "$Shortcut.WorkingDirectory = '%~dp0'; " ^
  "$Shortcut.IconLocation = (Join-Path '%~dp0' 'icons\electriapp.ico'); " ^
  "$Shortcut.Description = 'ElectriApp SIGES-ELEC - Gestion de Servicios Tecnicos'; " ^
  "$Shortcut.Save();"

if %errorlevel%==0 (
    echo [OK] Acceso directo "ElectriApp SIGES" creado en tu Escritorio!
    echo      Ya podes abrir la app con doble clic desde el Escritorio.
) else (
    echo [ERROR] No se pudo crear el acceso directo automaticamente.
    echo         Podes hacer clic derecho en "Iniciar-ElectriApp.bat" ^> Enviar a ^> Escritorio.
)

echo.
pause
