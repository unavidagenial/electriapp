const CACHE_NAME = "electriapp-siges-v2-cache";
const STATIC_ASSETS = [
    "./",
    "./index.html",
    "./style.css",
    "./script.js",
    "./manifest.json",
    "./icons/icon-192.png",
    "./icons/icon-512.png"
];

self.addEventListener("install", (event) => {
    event.waitUntil(
        caches.open(CACHE_NAME).then((cache) => cache.addAll(STATIC_ASSETS))
    );
    self.skipWaiting();
});

self.addEventListener("activate", (event) => {
    event.waitUntil(
        caches.keys().then((keys) =>
            Promise.all(keys.filter((k) => k !== CACHE_NAME).map((k) => caches.delete(k)))
        )
    );
    self.clients.claim();
});

self.addEventListener("fetch", (event) => {
    const req = event.request;
    // No cachear peticiones a la API de MySQL
    if (req.url.includes("/api/") || req.method !== "GET") {
        return;
    }

    event.respondWith(
        fetch(req)
            .then((networkRes) => {
                const clone = networkRes.clone();
                caches.open(CACHE_NAME).then((cache) => cache.put(req, clone));
                return networkRes;
            })
            .catch(() => caches.match(req))
    );
});
